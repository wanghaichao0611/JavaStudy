create procedure addSub(INOUT num1 int, INOUT num2 int)
begin
set num1=num1+num2;
set num2=num1-num2-num2;
end;

