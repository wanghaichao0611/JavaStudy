create procedure addStudent(IN no char(9), IN name char(12), IN sex char(2), IN age int, IN object char(50))
begin
 insert into student values(no,name,sex,age,object);
end;

