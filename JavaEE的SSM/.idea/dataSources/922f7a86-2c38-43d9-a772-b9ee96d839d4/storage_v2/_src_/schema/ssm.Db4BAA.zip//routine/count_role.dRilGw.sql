create procedure count_role(IN p_role_name varchar(20), OUT count_total int, OUT exec_date date)
begin
  select count(*) into count_total from t_role where role_name like concat(p_role_name,'%');
  select sysdate() into  exec_date from dual;
end;

